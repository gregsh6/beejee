<?php
/**
 * Пытаемся подключить нужные файлы
 * @param $className - нужный класс
*/
spl_autoload_register(function($className) {
    $file = __DIR__ . '\\..\\controllers\\' . strtolower($className) . '.php';
	$file = str_replace('\\', DIRECTORY_SEPARATOR, $file);

	if (file_exists($file)) {
		include $file;
	}
    else{
        $file = __DIR__ . '\\..\\models\\' . strtolower($className) . '.php';
    	$file = str_replace('\\', DIRECTORY_SEPARATOR, $file);

        if (file_exists($file)) {
            include $file;
        }
        else {
            $file = __DIR__ . '\\' . strtolower($className) . '.php';
        	$file = str_replace('\\', DIRECTORY_SEPARATOR, $file);

            if (file_exists($file)) {
                include $file;
            }
        }
    }
});
