<?php
class Mysql {
	private $pdo;

    /**
     * Подключаемся к БД
     * @return pdo
    */
	public function connect() {
		if ($this->pdo == null) {
			$this->pdo = new \PDO("mysql:host=localhost;dbname=yourdbname",  "yourusername", "yourdbpassword");
		}
		return $this->pdo;
	}
}
