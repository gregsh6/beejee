<?php
// Подключаем автозагрузку файлов
include $_SERVER['DOCUMENT_ROOT'].'/include/autoload.php';

// Стартуем сессию
session_start();

// Обрабатываем события
if(!empty($_POST)){
    $task = new Task_Controller();
    switch($_POST["action"]){
        // Авторизация
        case "login":
            $result = $task->login($_POST);
        break;
        // Выход из админа
        case "logout":
            $result = $task->logout();
        break;
        // Получение списка задач
        case "list":
            $result = $task->list($_POST);
        break;
        // Добавление новой задачи
        case "add":
            $result = $task->add($_POST);
        break;
        // Редактирование задачи
        case "edit":
            $result = $task->edit($_POST);
        break;
        default:
            array("result"=>"er", "message"=> "Не допустимое действие!");
    }

    // Возвращаем json
    header("Cache-Control: no-cache, must-revalidate");
    header("Content-type: application/json");
    exit(json_encode($result));
}

// Выводим шаблоны
include ($_SERVER['DOCUMENT_ROOT'].'/views/header.html');
include ($_SERVER['DOCUMENT_ROOT'].'/views/task/index.html');
include ($_SERVER['DOCUMENT_ROOT'].'/views/footer.html');
