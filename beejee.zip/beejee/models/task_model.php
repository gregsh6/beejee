<?php
class Task_Model {
    function __construct() {
        // получаем доступ к БД
        $this->pdo = (new Mysql())->connect();
        if ($this->pdo === null) {
        	return "Ошибка: не возможно подключиться к базе данных!";
        }
    }

    /**
     * Получение списка задач
     * @param int $page - страница пагинации
     * @param string $sort - по какому полю сортируем
     * @param string $direction - по возрастанию или убыванию
     * @return array [tasks => Упорядоченный массив с задачами, count => всего задач, num_pages => всего страниц, admin => авторизованы или нет]
    */
    public function getList($page, $sort, $direction){
        // Получаем общее количество задач и страниц
        $count_query = "SELECT COUNT(id) AS count FROM tasks";
        $count_prepared_query = $this->pdo->prepare($count_query);
        $count_prepared_query->execute();
        $count_query = $count_prepared_query->fetchAll();
        $rtn["count"] = $count_query ? $count_query[0]['count'] : 0;
        $rtn["num_pages"] = ceil($rtn["count"] / 3);

        // Получаем сами задачи
        if($rtn["count"] > 0){
            $query = "SELECT * FROM tasks ORDER BY ".$sort." ".$direction." LIMIT 3 OFFSET :page";
            $prepared_query = $this->pdo->prepare($query);
            $prepared_query->bindValue(':page', ($page-1)*3, PDO::PARAM_INT);

            if (!$prepared_query->execute()) {
                print_r($prepared_query->errorInfo());
            }
            $rtn["tasks"] = $prepared_query->fetchAll();
        }
        else {
            $rtn["tasks"] = array();
        }

        // авторизованы или нет
        $rtn["admin"] = isset($_SESSION["admin"]) ? true : false;

        return $rtn;
    }

    /**
     * Добавление новой задачи
     * @param array $data - входные данные
     * @return bool успешно или нет
    */
    public function add($data){
        // Запрос
        $query = "INSERT INTO tasks(name, email, content) VALUES ( :name, :email, :content )";

        // Подставляем данные
        $prepared_statement = $this->pdo->prepare($query);
        $prepared_statement->bindParam("name", htmlspecialchars($data["name"]));
        $prepared_statement->bindParam("email", $data["email"]);
        $prepared_statement->bindParam("content", htmlspecialchars($data["content"]));

        // Выполняем
        $prepared_statement->execute();

        return $prepared_statement->rowCount();
    }

    /**
     * Редактирование задачи
     * @param array $data - входные данные
     * @return bool успешно или нет
    */
    public function edit($data){
        // Только авторизованные пользователи могут редактировать
        if(isset($_SESSION["admin"])){
            $query = "SELECT * FROM tasks WHERE id=:id LIMIT 0,1";
            $prepared_query = $this->pdo->prepare($query);
            $prepared_query->bindParam("id", $data["id"], PDO::PARAM_INT);
            $prepared_query->execute();
            $task = $prepared_query->fetchAll();

            if(isset($task[0]) && $task[0]["id"] > 0) {
                // Проверяем поменялся ли текст задачи
                $modified = ($task[0]["modified"] == "0000-00-00 00:00:00" && $task[0]["content"] == htmlspecialchars($data["content"])) ? $task[0]["created"] : date("Y-m-d H:i:s");

                // Запрос
                $query = "UPDATE tasks SET content=:content, status=:status, modified=:modified WHERE id=:id";

                // Подставляем данные
                $prepared_statement = $this->pdo->prepare($query);
                $prepared_statement->bindParam("content", htmlspecialchars($data["content"]));
                $prepared_statement->bindParam("status", $data["status"], PDO::PARAM_INT);
                $prepared_statement->bindParam("modified", $modified);
                $prepared_statement->bindParam("id", $data["id"], PDO::PARAM_INT);

                // Выполняем
                $prepared_statement->execute();

                return $prepared_statement->rowCount();
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
}
