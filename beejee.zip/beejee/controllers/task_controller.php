<?php
class Task_Controller {

    public $errors = false;

    function __construct() {
        // Инициализируем модель задач
        $this->model = new Task_Model();
    }

    /**
     * Авторизация
     * @param array $p - входные данные
     * @return array [result => ok|er, message => сообщение с результатом вызова]
    */
    public function login($p){
        if($p["login"] == "admin" && $p["password"] == "123"){
            $_SESSION["admin"] = true;
            return array("result"=>"ok", "message"=>"Вы успешно вошли!");
        }
        else {
            return array("result"=>"er", "message"=>"Неправильный логин / пароль!");
        }
    }

    /**
     * Выход из админа
     * @return array [result => ok, message => сообщение с результатом вызова]
    */
    public function logout(){
        unset($_SESSION["admin"]);
        return array("result"=>"ok", "message"=>"Вы успешно вышли!");
    }

    /**
     * Список задач
     * @param array $p - входные данные
     * @return array [tasks => Упорядоченный массив с задачами, count => всего задач, num_pages => всего страниц, admin => авторизованы или нет]
    */
    public function list($p) {
        // Проверяем страницу пагинации
        $p["page"] = ltrim(preg_replace("/[^0-9\-]/isu","",$p["page"]),"0");
        $p["page"] = ($p["page"] || $p["page"]==0) ? $p["page"] : 1;

        // Проверяем параметр сортировки
        $sort = array("id", "name", "email", "status");
        $p["sort"] = in_array($p["sort"], $sort) ? $p["sort"] : "id";

        // Проверяем параметр направления сортировки
        $p["direction"] = $p["direction"] == "asc" ? "ASC" : "DESC";

        return $this->model->getList($p["page"], $p["sort"], $p["direction"]);
    }

    /**
     * Валидация данных
     * @param array $p - входные данные
     * @return array - проверенные входные данные
    */
    public function validate($p){
        $p["name"] = trim(preg_replace("/\s+/isu", " ", $p['name']));
        if(!$p["name"]){
            $this->errors[] = "Ошибка данных в поле 'Имя'!";
        }
        $p["email"] = filter_var(mb_strtolower(trim($p["email"])),FILTER_VALIDATE_EMAIL);
        if(!$p["email"]){
            $this->errors[] = "Ошибка данных в поле 'E-mail'!";
        }
        $p["content"] = trim(preg_replace("/ +/isu", " ", $p['content']));
        if(!$p["content"]){
            $this->errors[] = "Ошибка данных в поле 'Задача'!";
        }

        if(isset($p["id"])){
            $p["id"] = ltrim(preg_replace("/[^0-9]/isu","",$p["id"]),"0");
            if(!$p["id"]){
                $this->errors[] = "Ошибка данных!";
            }
        }

        return $p;
    }

    /**
     * Добавление новой задачи
     * @param array $p - входные данные
     * @return array [result => ok, message => сообщение с результатом вызова]
    */
    public function add($p){
        $p = $this->validate($p);
        if($this->errors){
            return array("result"=>"er", "message"=>$this->errors);
        }
        else {
            $result = $this->model->add(array("name"=>$p["name"], "email"=>$p["email"], "content"=>$p["content"]));
            if($result){
                return array("result"=>"ok", "message"=>"Задача успешно добавлена!");
            }
            else {
                return array("result"=>"er", "message"=>"Ошибка запроса!");
            }
        }
    }

    /**
     * Редактирование задачи
     * @param array $p - входные данные
     * @return array [result => ok, message => сообщение с результатом вызова]
    */
    public function edit($p){
        $p = $this->validate($p);

        if($this->errors){
            return array("result"=>"er", "message"=>$this->errors);
        }
        else {
            $result = $this->model->edit(array("name"=>$p["name"], "email"=>$p["name"], "content"=>$p["content"], "status"=>(isset($p["status"]) ? 1 : 0), "id"=>$p["id"]));
            if($result){
                return array("result"=>"ok", "message"=>"Задача успешно сохранена!");
            }
            else {
                return array("result"=>"er", "message"=>"Ошибка запроса!");
            }
        }
    }
}
?>
