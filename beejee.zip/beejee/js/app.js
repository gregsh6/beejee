$(function() {
    // получаем список задач
    getTaskList();

    // событие на кнопку "Выход"
    $("#logoutBTN").on("click", function(e){
        e.preventDefault();
        e.stopPropagation();

        $.post("/",{ "action":"logout" }, function(response){
            $("#loginBTN").toggleClass("d-none");
            $("#logoutBTN").toggleClass("d-none");
            getTaskList();
        }, "json");

        return false;
    });

    // Очищаем модальное окно добавления новой задачи
    $("#addTask").on("show.bs.modal", function(event){
        var form = $(this).find("form:first");
        form.show();
        form.find("input").attr("value", "");
        form.find("textarea").text("");
        form.find("input[name=action]").attr("value", "add");
        $(this).find("p.h3").remove();
    });

    // Ловим отправку формы добавления новой задачи
    $("#addTask").find("form").on("submit", function(){
        // Очищаем ошибки
        $("#error-top").remove();
        var form = $(this);
        $.post("/", form.serialize(), function(response) {
            if(response.result == "ok"){
                // Если всё ок - Выводим соотвутсвующее сообщение, через 2 секунды закрываем форму, перезагружаем список задач
                form.hide();
                form.parent().append("<p class='h3 text-center mb-5'>"+response.message+"</p>");
                setTimeout(function(){
                    $("#addTask").modal('hide');
                    getTaskList();
                }, 2000);
            }
            else {
                // Выводим ошибку
                form.prepend("<p id='error-top' class='text-center' style='color:red;'>"+response.message+"</p>");
            }
        }, "json");

        return false;
    });

    // Ловим отправку формы редактирования задачи
    $("#editTask").find("form").on("submit", function(){
        // Очищаем ошибки
        $("#error-top").remove();
        var form = $(this);
        $.post("/", form.serialize(), function(response) {
            if(response.result == "ok"){
                // Если всё ок - Выводим соотвутсвующее сообщение, через 2 секунды закрываем форму, перезагружаем список задач
                form.hide();
                form.parent().append("<p class='h3 text-center mb-5'>"+response.message+"</p>");
                setTimeout(function(){
                    $("#editTask").modal('hide');
                    getTaskList();
                }, 2000);
            }
            else {
                // Выводим ошибку
                form.prepend("<p id='error-top' class='text-center' style='color:red;'>"+response.message+"</p>");
            }
        }, "json");

        return false;
    });

    // Ловим отправку формы авторизации
    $("#login").find("form").on("submit", function(){
        // Очищаем ошибки
        $("#error-top").remove();
        var form = $(this);
        $.post("/", form.serialize(), function(response) {
            if(response.result == "ok"){
                // Если всё ок - Выводим соотвутсвующее сообщение, скрываем кнопку логина и показываем кнопку выхода, через 2 секунды закрываем форму
                form.hide();
                form.parent().append("<p class='h3 text-center mb-5'>"+response.message+"</p>");

                $("#loginBTN").toggleClass("d-none");
                $("#logoutBTN").toggleClass("d-none");
                getTaskList();

                setTimeout(function(){
                    $("#login").modal('hide');
                }, 2000);
            }
            else {
                // Выводим ошибку
                form.prepend("<p id='error-top' class='text-center' style='color:red;'>"+response.message+"</p>");
            }
        }, "json");

        return false;
    });
});

// Получение списка задач
function getTaskList(page, sort, direction){
    page = page ? page : 1;
    sort = sort ? sort : "id";
    direction = direction ? direction : "asc";

    $.post(
        "/",
        {
            "action": "list",
            "page": page,
            "sort": sort,
            "direction": direction
        },
        function(response) {
            // Очищаем контейнер
            var tasksList = $("#tasksList");
            tasksList.unbind("click");
            tasksList.text("");
            tasksList.append("<p class=\"mt-4\">Всего задач: "+response.count+"</p>");
            if(response.count > 0){
                // Формируем список задач
                var tbody = $("<tbody></tbody>");
                $.each(response.tasks, function(i, task) {
                    tbody.append(
                        $("<tr></tr>")
                            .append("<th scope=\"row\">"+task.id+"</th>")
                            .append("<th>"+task.name+"</th>")
                            .append("<th>"+task.email+"</th>")
                            .append("<th>"+task.content+"</th>")
                            .append("<th>"+(task.status > 0 ? "Выполнено" : "В процессе")+(task.modified && task.modified != "0000-00-00 00:00:00" && task.created != task.modified ? "<br /><i>отредактировано администратором</i>" : "")+"</th>")
                            .append(response.admin ? (
                                $("<th></th>")
                                    .append(
                                        $("<a data-action=\"edit\" href=\"edit\">Редактировать</a>")
                                            .data("task", task)
                                    )
                            ) : "")
                    );
                });

                // Формируем заголовки таблицы
                tasksList.append(
                    $("<table class=\"table\"></table>")
                        .append(
                            $("<thead></thead>")
                                .append(
                                    $("<tr></tr>")
                                        .append("<th scope=\"col\"><a data-action=\"sort\" data-sort=\"id\" data-direction=\""+(sort != "id" ? "asc" : direction == "asc" ? "desc" : "asc")+"\" href=\"#\"># "+(sort == "id" ? (direction == "asc" ? "&#8593;" : "&#8595;") : "")+"</a></th>")
                                        .append("<th scope=\"col\"><a data-action=\"sort\" data-sort=\"name\" data-direction=\""+(sort != "name" ? "asc" : direction == "asc" ? "desc" : "asc")+"\" href=\"#\">Имя "+(sort == "name" ? (direction == "asc" ? "&#8593;" : "&#8595;") : "")+"</a></th>")
                                        .append("<th scope=\"col\"><a data-action=\"sort\" data-sort=\"email\" data-direction=\""+(sort != "email" ? "asc" : direction == "asc" ? "desc" : "asc")+"\" href=\"#\">E-mail "+(sort == "email" ? (direction == "asc" ? "&#8593;" : "&#8595;") : "")+"</a></th>")
                                        .append("<th scope=\"col\">Задача</th>")
                                        .append("<th scope=\"col\"><a data-action=\"sort\" data-sort=\"status\" data-direction=\""+(sort != "status" ? "asc" : direction == "asc" ? "desc" : "asc")+"\" href=\"#\">Статус "+(sort == "status" ? (direction == "asc" ? "&#8593;" : "&#8595;") : "")+"</a></th>")
                                        .append(response.admin ? "<th scope=\"col\">Действия</th>" : "")
                                )
                        )
                        .append(tbody)
                );

                if(response.num_pages > 1){
                    // Добавляем пагинацию, если необходимо
                    var ul = $("<ul class=\"pagination\"></ul>");
                    for (var i = 1; i <= response.num_pages; i++) {
                        $(ul).append("<li class=\"page-item"+(i == page ? " active" : "")+"\"><a data-action=\"gotopage\" data-page=\""+i+"\" class=\"page-link\" href=\"page"+i+"\">"+i+"</a></li>");
                	}
                    tasksList.append(ul);
                }

                // Ловим нажатия
                tasksList.on("click","*[data-action]",function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    var caller = $(this);
                    switch(caller.data("action")) {
                        // Страница пагинации
                        case "gotopage":
                            if(caller.data("page") != page){
                                getTaskList(caller.data("page"), sort, direction);
                            }
                        break;
                        // Ссылка редактировать
                        case "edit":
                            var item = caller.data("task");
                            form = $("#editTask").find("form:first");
                            form.closest("div.modal-body").find("p.h3").remove();
                            form.show();
                            form.find("input[name=name]").attr("value", item.name);
                            form.find("input[name=email]").attr("value", item.email);
                            form.find("input[name=id]").attr("value", item.id);
                            form.find("textarea").text(decodeHtml(item.content));

                            if(item.status > 0){
                                form.find("input[name=status]").prop("checked", true);
                            }
                            else {
                                form.find("input[name=status]").prop("checked", false);
                            }

                            form.find("#error-top").remove();

                            $("#editTask").modal('show');
                        break;
                        // Сортировка
                        case "sort":
                            getTaskList(page, caller.data("sort"), caller.data("direction"));
                        break;
                    }
                });
            }
        },
        "json"
    );
}

// Преобразуем html символы в человеческий формат
function decodeHtml(text) {
    return text
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g , '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g,'"')
        .replace(/&#039;/g,"'");
}
